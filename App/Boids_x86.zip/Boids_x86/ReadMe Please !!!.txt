Source Code: https://github.com/IrfanJames/Boids-SFML.git


Controls:
---------------------------------------------------------
1.  1     | Rule-1 (Separation)
2.  2     | Rule-2 (Alignment)
3.  3     | Rule-3 (Cohesion
          |
4.  +     | Add  some Boids
5.  -     | Kill some Boids
          |
6.  F     | Follow Cursor
7.  P     | Preditor Mode
          |
8.  Tab   | Menu
9.  M     | Mute/Unmute
10. R     | Escape
11. Space | Pause/Play
12. Esc   | Escape
13. Move Cursor to change (green sector) in Menu to set the Feild-of-view of Boids
---------------------------------------------------------

Enjoy!
Would love some suggestions.